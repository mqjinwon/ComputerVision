/********************************************************************************
** Form generated from reading UI file 'mainframe.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINFRAME_H
#define UI_MAINFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainFrame
{
public:
    QVBoxLayout *verticalLayout;
    QFrame *frame;
    QHBoxLayout *horizontalLayout_3;
    QToolButton *buttonOpen;
    QToolButton *toolButton_2;
    QToolButton *toolButton_3;
    QToolButton *buttonDeleteContents;
    QSpacerItem *horizontalSpacer;
    QToolButton *buttonShowList;
    QHBoxLayout *horizontalLayout;
    QTabWidget *tabWidget;
    QWidget *tab_0;
    QLabel *label_5;
    QSpinBox *spinHue;
    QLabel *label_6;
    QDoubleSpinBox *spinSaturation;
    QPushButton *buttonSepiaTone;
    QPushButton *buttonContrast;
    QSpinBox *spinMin;
    QSpinBox *spinMax;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *tab_1;
    QPushButton *buttonOtsu;
    QPushButton *buttonMorp;
    QComboBox *cbMorp;
    QPushButton *buttonLabel;
    QWidget *tab_2;
    QPushButton *buttonHistoMatch;
    QPushButton *buttonHistoEqual;
    QWidget *tab_3;
    QPushButton *buttonGN;
    QPushButton *buttonSalt;
    QPushButton *buttonGF;
    QPushButton *buttonMF;
    QWidget *tab_4;
    QPushButton *buttonFDG;
    QPushButton *buttonCE;
    QSpinBox *spinMin_t0;
    QSpinBox *spinMin_t1;
    QLabel *label;
    QLabel *label_2;
    QWidget *tab_5;
    QPushButton *buttonCHT;
    QPushButton *buttonGHT;
    QLabel *label_3;
    QCheckBox *checkBoxRadius;
    QLabel *label_4;
    QPlainTextEdit *plainTextEditMinR;
    QPlainTextEdit *plainTextEditMaxR;
    QLabel *label_9;
    QPlainTextEdit *plainTextEditRadius;
    QLabel *label_10;
    QDoubleSpinBox *doubleSpinBoxThreshold;
    QTextBrowser *textBrowserResult;
    QListWidget *listWidget;

    void setupUi(QDialog *MainFrame)
    {
        if (MainFrame->objectName().isEmpty())
            MainFrame->setObjectName(QStringLiteral("MainFrame"));
        MainFrame->resize(576, 461);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainFrame->sizePolicy().hasHeightForWidth());
        MainFrame->setSizePolicy(sizePolicy);
        MainFrame->setMinimumSize(QSize(0, 461));
        MainFrame->setModal(false);
        verticalLayout = new QVBoxLayout(MainFrame);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        frame = new QFrame(MainFrame);
        frame->setObjectName(QStringLiteral("frame"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy1);
        frame->setMinimumSize(QSize(0, 41));
        frame->setMaximumSize(QSize(16777215, 41));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Raised);
        horizontalLayout_3 = new QHBoxLayout(frame);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        buttonOpen = new QToolButton(frame);
        buttonOpen->setObjectName(QStringLiteral("buttonOpen"));
        buttonOpen->setEnabled(true);
        sizePolicy.setHeightForWidth(buttonOpen->sizePolicy().hasHeightForWidth());
        buttonOpen->setSizePolicy(sizePolicy);
        buttonOpen->setMinimumSize(QSize(41, 41));
        buttonOpen->setMaximumSize(QSize(41, 41));
        buttonOpen->setLayoutDirection(Qt::LeftToRight);
        buttonOpen->setAutoFillBackground(false);
        QIcon icon;
        icon.addFile(QStringLiteral(":/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        buttonOpen->setIcon(icon);
        buttonOpen->setIconSize(QSize(41, 41));
        buttonOpen->setCheckable(false);
        buttonOpen->setAutoRepeat(false);
        buttonOpen->setAutoExclusive(false);
        buttonOpen->setPopupMode(QToolButton::DelayedPopup);
        buttonOpen->setToolButtonStyle(Qt::ToolButtonIconOnly);
        buttonOpen->setAutoRaise(false);

        horizontalLayout_3->addWidget(buttonOpen);

        toolButton_2 = new QToolButton(frame);
        toolButton_2->setObjectName(QStringLiteral("toolButton_2"));
        sizePolicy.setHeightForWidth(toolButton_2->sizePolicy().hasHeightForWidth());
        toolButton_2->setSizePolicy(sizePolicy);
        toolButton_2->setMinimumSize(QSize(41, 41));
        toolButton_2->setMaximumSize(QSize(41, 41));

        horizontalLayout_3->addWidget(toolButton_2);

        toolButton_3 = new QToolButton(frame);
        toolButton_3->setObjectName(QStringLiteral("toolButton_3"));
        sizePolicy.setHeightForWidth(toolButton_3->sizePolicy().hasHeightForWidth());
        toolButton_3->setSizePolicy(sizePolicy);
        toolButton_3->setMinimumSize(QSize(41, 41));
        toolButton_3->setMaximumSize(QSize(41, 41));

        horizontalLayout_3->addWidget(toolButton_3);

        buttonDeleteContents = new QToolButton(frame);
        buttonDeleteContents->setObjectName(QStringLiteral("buttonDeleteContents"));
        sizePolicy.setHeightForWidth(buttonDeleteContents->sizePolicy().hasHeightForWidth());
        buttonDeleteContents->setSizePolicy(sizePolicy);
        buttonDeleteContents->setMinimumSize(QSize(41, 41));
        buttonDeleteContents->setMaximumSize(QSize(41, 41));
        buttonDeleteContents->setAutoFillBackground(false);
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/1-21.png"), QSize(), QIcon::Normal, QIcon::Off);
        buttonDeleteContents->setIcon(icon1);
        buttonDeleteContents->setIconSize(QSize(41, 41));

        horizontalLayout_3->addWidget(buttonDeleteContents);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        buttonShowList = new QToolButton(frame);
        buttonShowList->setObjectName(QStringLiteral("buttonShowList"));
        sizePolicy.setHeightForWidth(buttonShowList->sizePolicy().hasHeightForWidth());
        buttonShowList->setSizePolicy(sizePolicy);
        buttonShowList->setMinimumSize(QSize(41, 41));
        buttonShowList->setMaximumSize(QSize(41, 41));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/2-3.png"), QSize(), QIcon::Normal, QIcon::Off);
        buttonShowList->setIcon(icon2);
        buttonShowList->setIconSize(QSize(82, 41));

        horizontalLayout_3->addWidget(buttonShowList);


        verticalLayout->addWidget(frame);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(2, -1, -1, -1);
        tabWidget = new QTabWidget(MainFrame);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setEnabled(true);
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy2);
        tabWidget->setMinimumSize(QSize(299, 394));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        QBrush brush1(QColor(255, 85, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::NoRole, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::NoRole, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::NoRole, brush1);
        tabWidget->setPalette(palette);
        tabWidget->setCursor(QCursor(Qt::ArrowCursor));
        tabWidget->setAutoFillBackground(false);
        tabWidget->setTabPosition(QTabWidget::North);
        tabWidget->setTabShape(QTabWidget::Rounded);
        tabWidget->setIconSize(QSize(31, 31));
        tabWidget->setElideMode(Qt::ElideMiddle);
        tab_0 = new QWidget();
        tab_0->setObjectName(QStringLiteral("tab_0"));
        label_5 = new QLabel(tab_0);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(45, 83, 31, 16));
        spinHue = new QSpinBox(tab_0);
        spinHue->setObjectName(QStringLiteral("spinHue"));
        spinHue->setGeometry(QRect(80, 80, 61, 22));
        spinHue->setAlignment(Qt::AlignCenter);
        spinHue->setMaximum(360);
        spinHue->setSingleStep(20);
        spinHue->setValue(360);
        label_6 = new QLabel(tab_0);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(145, 83, 31, 16));
        spinSaturation = new QDoubleSpinBox(tab_0);
        spinSaturation->setObjectName(QStringLiteral("spinSaturation"));
        spinSaturation->setGeometry(QRect(180, 80, 62, 22));
        spinSaturation->setAlignment(Qt::AlignCenter);
        spinSaturation->setMaximum(1);
        spinSaturation->setSingleStep(0.1);
        spinSaturation->setValue(0.3);
        buttonSepiaTone = new QPushButton(tab_0);
        buttonSepiaTone->setObjectName(QStringLiteral("buttonSepiaTone"));
        buttonSepiaTone->setGeometry(QRect(45, 30, 201, 41));
        buttonSepiaTone->setAutoFillBackground(false);
        buttonSepiaTone->setIconSize(QSize(41, 41));
        buttonSepiaTone->setCheckable(false);
        buttonSepiaTone->setAutoRepeat(false);
        buttonSepiaTone->setAutoExclusive(false);
        buttonSepiaTone->setAutoDefault(true);
        buttonSepiaTone->setFlat(false);
        buttonContrast = new QPushButton(tab_0);
        buttonContrast->setObjectName(QStringLiteral("buttonContrast"));
        buttonContrast->setGeometry(QRect(45, 140, 201, 41));
        buttonContrast->setAutoFillBackground(false);
        buttonContrast->setIconSize(QSize(41, 41));
        buttonContrast->setCheckable(false);
        buttonContrast->setAutoRepeat(false);
        buttonContrast->setAutoExclusive(false);
        buttonContrast->setAutoDefault(true);
        buttonContrast->setFlat(false);
        spinMin = new QSpinBox(tab_0);
        spinMin->setObjectName(QStringLiteral("spinMin"));
        spinMin->setGeometry(QRect(80, 190, 61, 22));
        spinMin->setAlignment(Qt::AlignCenter);
        spinMin->setMaximum(360);
        spinMin->setSingleStep(20);
        spinMin->setValue(0);
        spinMax = new QSpinBox(tab_0);
        spinMax->setObjectName(QStringLiteral("spinMax"));
        spinMax->setGeometry(QRect(180, 190, 61, 22));
        spinMax->setAlignment(Qt::AlignCenter);
        spinMax->setMaximum(360);
        spinMax->setSingleStep(20);
        spinMax->setValue(255);
        label_7 = new QLabel(tab_0);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(45, 193, 31, 16));
        label_8 = new QLabel(tab_0);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(145, 193, 31, 16));
        tabWidget->addTab(tab_0, QString());
        tab_1 = new QWidget();
        tab_1->setObjectName(QStringLiteral("tab_1"));
        buttonOtsu = new QPushButton(tab_1);
        buttonOtsu->setObjectName(QStringLiteral("buttonOtsu"));
        buttonOtsu->setGeometry(QRect(45, 30, 201, 41));
        buttonOtsu->setAutoFillBackground(false);
        buttonOtsu->setIconSize(QSize(41, 41));
        buttonOtsu->setCheckable(false);
        buttonOtsu->setAutoRepeat(false);
        buttonOtsu->setAutoExclusive(false);
        buttonOtsu->setAutoDefault(true);
        buttonOtsu->setFlat(false);
        buttonMorp = new QPushButton(tab_1);
        buttonMorp->setObjectName(QStringLiteral("buttonMorp"));
        buttonMorp->setGeometry(QRect(145, 100, 100, 20));
        buttonMorp->setAutoFillBackground(false);
        buttonMorp->setIconSize(QSize(41, 41));
        buttonMorp->setCheckable(false);
        buttonMorp->setAutoRepeat(false);
        buttonMorp->setAutoExclusive(false);
        buttonMorp->setAutoDefault(true);
        buttonMorp->setFlat(false);
        cbMorp = new QComboBox(tab_1);
        cbMorp->setObjectName(QStringLiteral("cbMorp"));
        cbMorp->setGeometry(QRect(45, 100, 80, 20));
        buttonLabel = new QPushButton(tab_1);
        buttonLabel->setObjectName(QStringLiteral("buttonLabel"));
        buttonLabel->setGeometry(QRect(45, 150, 201, 41));
        buttonLabel->setAutoFillBackground(false);
        buttonLabel->setIconSize(QSize(41, 41));
        buttonLabel->setCheckable(false);
        buttonLabel->setAutoRepeat(false);
        buttonLabel->setAutoExclusive(false);
        buttonLabel->setAutoDefault(true);
        buttonLabel->setFlat(false);
        tabWidget->addTab(tab_1, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        buttonHistoMatch = new QPushButton(tab_2);
        buttonHistoMatch->setObjectName(QStringLiteral("buttonHistoMatch"));
        buttonHistoMatch->setGeometry(QRect(45, 100, 201, 41));
        buttonHistoMatch->setAutoFillBackground(false);
        buttonHistoMatch->setIconSize(QSize(41, 41));
        buttonHistoMatch->setCheckable(false);
        buttonHistoMatch->setAutoRepeat(false);
        buttonHistoMatch->setAutoExclusive(false);
        buttonHistoMatch->setAutoDefault(true);
        buttonHistoMatch->setFlat(false);
        buttonHistoEqual = new QPushButton(tab_2);
        buttonHistoEqual->setObjectName(QStringLiteral("buttonHistoEqual"));
        buttonHistoEqual->setGeometry(QRect(45, 30, 201, 41));
        buttonHistoEqual->setAutoFillBackground(false);
        buttonHistoEqual->setIconSize(QSize(41, 41));
        buttonHistoEqual->setCheckable(false);
        buttonHistoEqual->setAutoRepeat(false);
        buttonHistoEqual->setAutoExclusive(false);
        buttonHistoEqual->setAutoDefault(true);
        buttonHistoEqual->setFlat(false);
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        buttonGN = new QPushButton(tab_3);
        buttonGN->setObjectName(QStringLiteral("buttonGN"));
        buttonGN->setGeometry(QRect(45, 30, 201, 41));
        buttonGN->setAutoFillBackground(false);
        buttonGN->setIconSize(QSize(41, 41));
        buttonGN->setCheckable(false);
        buttonGN->setAutoRepeat(false);
        buttonGN->setAutoExclusive(false);
        buttonGN->setAutoDefault(true);
        buttonGN->setFlat(false);
        buttonSalt = new QPushButton(tab_3);
        buttonSalt->setObjectName(QStringLiteral("buttonSalt"));
        buttonSalt->setGeometry(QRect(45, 100, 201, 41));
        buttonSalt->setAutoFillBackground(false);
        buttonSalt->setIconSize(QSize(41, 41));
        buttonSalt->setCheckable(false);
        buttonSalt->setAutoRepeat(false);
        buttonSalt->setAutoExclusive(false);
        buttonSalt->setAutoDefault(true);
        buttonSalt->setFlat(false);
        buttonGF = new QPushButton(tab_3);
        buttonGF->setObjectName(QStringLiteral("buttonGF"));
        buttonGF->setGeometry(QRect(45, 170, 201, 41));
        buttonGF->setAutoFillBackground(false);
        buttonGF->setIconSize(QSize(41, 41));
        buttonGF->setCheckable(false);
        buttonGF->setAutoRepeat(false);
        buttonGF->setAutoExclusive(false);
        buttonGF->setAutoDefault(true);
        buttonGF->setFlat(false);
        buttonMF = new QPushButton(tab_3);
        buttonMF->setObjectName(QStringLiteral("buttonMF"));
        buttonMF->setGeometry(QRect(45, 240, 201, 41));
        buttonMF->setAutoFillBackground(false);
        buttonMF->setIconSize(QSize(41, 41));
        buttonMF->setCheckable(false);
        buttonMF->setAutoRepeat(false);
        buttonMF->setAutoExclusive(false);
        buttonMF->setAutoDefault(true);
        buttonMF->setFlat(false);
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        buttonFDG = new QPushButton(tab_4);
        buttonFDG->setObjectName(QStringLiteral("buttonFDG"));
        buttonFDG->setGeometry(QRect(45, 30, 201, 41));
        buttonFDG->setAutoFillBackground(false);
        buttonFDG->setIconSize(QSize(41, 41));
        buttonFDG->setCheckable(false);
        buttonFDG->setAutoRepeat(false);
        buttonFDG->setAutoExclusive(false);
        buttonFDG->setAutoDefault(true);
        buttonFDG->setFlat(false);
        buttonCE = new QPushButton(tab_4);
        buttonCE->setObjectName(QStringLiteral("buttonCE"));
        buttonCE->setGeometry(QRect(45, 100, 201, 41));
        buttonCE->setAutoFillBackground(false);
        buttonCE->setIconSize(QSize(41, 41));
        buttonCE->setCheckable(false);
        buttonCE->setAutoRepeat(false);
        buttonCE->setAutoExclusive(false);
        buttonCE->setAutoDefault(true);
        buttonCE->setFlat(false);
        spinMin_t0 = new QSpinBox(tab_4);
        spinMin_t0->setObjectName(QStringLiteral("spinMin_t0"));
        spinMin_t0->setGeometry(QRect(70, 150, 60, 22));
        spinMin_t0->setAlignment(Qt::AlignCenter);
        spinMin_t0->setMaximum(1000);
        spinMin_t0->setSingleStep(5);
        spinMin_t0->setValue(10);
        spinMin_t1 = new QSpinBox(tab_4);
        spinMin_t1->setObjectName(QStringLiteral("spinMin_t1"));
        spinMin_t1->setGeometry(QRect(185, 150, 60, 22));
        spinMin_t1->setAlignment(Qt::AlignCenter);
        spinMin_t1->setMaximum(1000);
        spinMin_t1->setSingleStep(5);
        spinMin_t1->setValue(30);
        label = new QLabel(tab_4);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(45, 153, 21, 16));
        label->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        label_2 = new QLabel(tab_4);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(160, 153, 21, 16));
        label_2->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        buttonCHT = new QPushButton(tab_5);
        buttonCHT->setObjectName(QStringLiteral("buttonCHT"));
        buttonCHT->setGeometry(QRect(45, 30, 201, 41));
        buttonCHT->setAutoFillBackground(false);
        buttonCHT->setIconSize(QSize(41, 41));
        buttonCHT->setCheckable(false);
        buttonCHT->setAutoRepeat(false);
        buttonCHT->setAutoExclusive(false);
        buttonCHT->setAutoDefault(true);
        buttonCHT->setFlat(false);
        buttonGHT = new QPushButton(tab_5);
        buttonGHT->setObjectName(QStringLiteral("buttonGHT"));
        buttonGHT->setGeometry(QRect(45, 150, 201, 41));
        buttonGHT->setAutoFillBackground(false);
        buttonGHT->setIconSize(QSize(41, 41));
        buttonGHT->setCheckable(false);
        buttonGHT->setAutoRepeat(false);
        buttonGHT->setAutoExclusive(false);
        buttonGHT->setAutoDefault(true);
        buttonGHT->setFlat(false);
        label_3 = new QLabel(tab_5);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(150, 90, 51, 16));
        label_3->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        checkBoxRadius = new QCheckBox(tab_5);
        checkBoxRadius->setObjectName(QStringLiteral("checkBoxRadius"));
        checkBoxRadius->setGeometry(QRect(55, 85, 61, 21));
        label_4 = new QLabel(tab_5);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(150, 120, 81, 16));
        label_4->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        plainTextEditMinR = new QPlainTextEdit(tab_5);
        plainTextEditMinR->setObjectName(QStringLiteral("plainTextEditMinR"));
        plainTextEditMinR->setGeometry(QRect(195, 80, 51, 30));
        plainTextEditMaxR = new QPlainTextEdit(tab_5);
        plainTextEditMaxR->setObjectName(QStringLiteral("plainTextEditMaxR"));
        plainTextEditMaxR->setGeometry(QRect(195, 110, 51, 30));
        label_9 = new QLabel(tab_5);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(50, 120, 51, 16));
        label_9->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        plainTextEditRadius = new QPlainTextEdit(tab_5);
        plainTextEditRadius->setObjectName(QStringLiteral("plainTextEditRadius"));
        plainTextEditRadius->setGeometry(QRect(95, 110, 51, 30));
        label_10 = new QLabel(tab_5);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(50, 205, 71, 16));
        label_10->setStyleSheet(QStringLiteral("color: rgb(85, 0, 0);"));
        doubleSpinBoxThreshold = new QDoubleSpinBox(tab_5);
        doubleSpinBoxThreshold->setObjectName(QStringLiteral("doubleSpinBoxThreshold"));
        doubleSpinBoxThreshold->setGeometry(QRect(125, 200, 121, 24));
        doubleSpinBoxThreshold->setDecimals(1);
        doubleSpinBoxThreshold->setMaximum(1e+126);
        doubleSpinBoxThreshold->setSingleStep(3);
        doubleSpinBoxThreshold->setValue(60);
        textBrowserResult = new QTextBrowser(tab_5);
        textBrowserResult->setObjectName(QStringLiteral("textBrowserResult"));
        textBrowserResult->setGeometry(QRect(45, 240, 201, 111));
        tabWidget->addTab(tab_5, QString());

        horizontalLayout->addWidget(tabWidget);

        listWidget = new QListWidget(MainFrame);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(listWidget->sizePolicy().hasHeightForWidth());
        listWidget->setSizePolicy(sizePolicy3);
        listWidget->setMinimumSize(QSize(0, 394));
        QPalette palette1;
        QBrush brush2(QColor(255, 255, 0, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush3(QColor(0, 0, 127, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush3);
        QBrush brush4(QColor(255, 255, 255, 128));
        brush4.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Active, QPalette::PlaceholderText, brush4);
#endif
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush3);
        QBrush brush5(QColor(255, 255, 255, 128));
        brush5.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush5);
#endif
        QBrush brush6(QColor(120, 120, 120, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush6);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush6);
        QBrush brush7(QColor(240, 240, 240, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush7);
        QBrush brush8(QColor(255, 255, 255, 128));
        brush8.setStyle(Qt::NoBrush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush8);
#endif
        listWidget->setPalette(palette1);
        QFont font;
        font.setFamily(QStringLiteral("Times New Roman"));
        font.setPointSize(10);
        listWidget->setFont(font);

        horizontalLayout->addWidget(listWidget);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(MainFrame);

        tabWidget->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(MainFrame);
    } // setupUi

    void retranslateUi(QDialog *MainFrame)
    {
        MainFrame->setWindowTitle(QApplication::translate("MainFrame", "Homeworks", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        buttonOpen->setToolTip(QApplication::translate("MainFrame", "open an image file", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        buttonOpen->setText(QString());
        toolButton_2->setText(QApplication::translate("MainFrame", "...", Q_NULLPTR));
        toolButton_3->setText(QApplication::translate("MainFrame", "...", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        buttonDeleteContents->setToolTip(QApplication::translate("MainFrame", "close all forms", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        buttonDeleteContents->setText(QString());
#ifndef QT_NO_TOOLTIP
        buttonShowList->setToolTip(QApplication::translate("MainFrame", "show the list view", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
        buttonShowList->setText(QString());
        label_5->setText(QApplication::translate("MainFrame", "Hue", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainFrame", "Sat.", Q_NULLPTR));
        buttonSepiaTone->setText(QApplication::translate("MainFrame", "Sepia Tone", Q_NULLPTR));
        buttonContrast->setText(QApplication::translate("MainFrame", "Contrast Transfrom", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainFrame", "Min", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainFrame", "Max", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_0), QApplication::translate("MainFrame", " cv 1 ", Q_NULLPTR));
        buttonOtsu->setText(QApplication::translate("MainFrame", "Otsu Thershold", Q_NULLPTR));
        buttonMorp->setText(QApplication::translate("MainFrame", "Morphology", Q_NULLPTR));
        cbMorp->clear();
        cbMorp->insertItems(0, QStringList()
         << QApplication::translate("MainFrame", "Dilation", Q_NULLPTR)
         << QApplication::translate("MainFrame", "Erosion", Q_NULLPTR)
         << QApplication::translate("MainFrame", "Opening", Q_NULLPTR)
         << QApplication::translate("MainFrame", "Closing", Q_NULLPTR)
        );
        buttonLabel->setText(QApplication::translate("MainFrame", "Labeling", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_1), QApplication::translate("MainFrame", " cv 2 ", Q_NULLPTR));
        buttonHistoMatch->setText(QApplication::translate("MainFrame", "Histogram Matching", Q_NULLPTR));
        buttonHistoEqual->setText(QApplication::translate("MainFrame", "Histogram Equalization", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainFrame", " cv 3 ", Q_NULLPTR));
        buttonGN->setText(QApplication::translate("MainFrame", "Gaussian Noise", Q_NULLPTR));
        buttonSalt->setText(QApplication::translate("MainFrame", "Pepper_Salt Noise", Q_NULLPTR));
        buttonGF->setText(QApplication::translate("MainFrame", "Gaussian Filter", Q_NULLPTR));
        buttonMF->setText(QApplication::translate("MainFrame", "Median Filter", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainFrame", " cv 4 ", Q_NULLPTR));
        buttonFDG->setText(QApplication::translate("MainFrame", "FDG", Q_NULLPTR));
        buttonCE->setText(QApplication::translate("MainFrame", "canny edge", Q_NULLPTR));
        label->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">t0: </span></p></body></html>", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">t1: </span></p></body></html>", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainFrame", " cv 5", Q_NULLPTR));
        buttonCHT->setText(QApplication::translate("MainFrame", "Circle Hough Transform", Q_NULLPTR));
        buttonGHT->setText(QApplication::translate("MainFrame", "General Hough Transform", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:8pt; font-weight:600;\">MinR: </span></p></body></html>", Q_NULLPTR));
        checkBoxRadius->setText(QApplication::translate("MainFrame", "radius", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:8pt; font-weight:600;\">MaxR: </span></p></body></html>", Q_NULLPTR));
        plainTextEditMinR->setPlainText(QApplication::translate("MainFrame", "10", Q_NULLPTR));
        plainTextEditMaxR->setPlainText(QApplication::translate("MainFrame", "70", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:8pt; font-weight:600;\">radius:</span></p></body></html>", Q_NULLPTR));
        plainTextEditRadius->setPlainText(QApplication::translate("MainFrame", "51.5", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainFrame", "<html><head/><body><p><span style=\" font-size:8pt; font-weight:600;\">Threshold : </span></p></body></html>", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainFrame", " cv 6", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainFrame: public Ui_MainFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINFRAME_H
