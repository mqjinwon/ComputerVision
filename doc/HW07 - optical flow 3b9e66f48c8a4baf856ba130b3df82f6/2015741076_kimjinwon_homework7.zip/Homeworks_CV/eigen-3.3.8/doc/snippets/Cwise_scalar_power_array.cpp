Array<double,1,3> e(2,-3,1./3.);
cout << "10^[" << e << "] = " << pow(10,e) << endl;
