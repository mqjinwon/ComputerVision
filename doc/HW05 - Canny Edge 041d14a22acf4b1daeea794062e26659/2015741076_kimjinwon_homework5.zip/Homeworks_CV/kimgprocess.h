#ifndef KIMGPROCESS_H
#define KIMGPROCESS_H

#include "kfc.h"
#include <vector>
#include <queue>
#include <stack>
#include <qcustomplot.h>

using namespace std;

#define DEBUG 0

/* 0 : 검은색, 255 : 흰색
 * _BACKGROUND : 255(foreground), 0(background)
 * _FOREGROUND : 0(foreground), 255(background)
 */
#define		_BACKGROUND         0
#define		_FOREGROUND         1

// edge 관련 정보이다.
struct EdgeData{
    double dx;
    double dy;
    double magn;
    int    dir;     // 8개의 방향이 존재할 수 있다.
};

typedef     vector<vector<int>*>        _1DPIXEL;
typedef     vector<vector<EdgeData>*>   _EDGEIMG;   //edge 정보를 담은 이미지 데이터이다.

class KImgProcess
{
private:
    QCustomPlot*    customPlot;
    // 우측부터 아래로 탐색
    int             eightNeighborRow[8] = {0, 1, 1, 1, 0, -1, -1, -1};
    int             eightNeighborCol[8] = {1, 1, 0, -1, -1, -1, 0, 1};

    KRandom*        Random;
    KGaussian*      GRandom;

    _EDGEIMG        edgeData;   // edge 정보를 담은 이미지 데이터이다.

public:

    KImgProcess();
    ~KImgProcess();

    KImageColor SepiaTransform(KImageColor igColor, int pHue, double pSat);

    KImageColor ContrastTransform(KImageColor& igColor, int pMin=0, int pMax=255);
    void        ContrastTransform(KImageGray& igGray, int pMin=0, int pMax=255);

    void        OtsuThreshold(KImageGray& igGray);

    KImageGray  Dilation(KImageGray& igGray, int mSize = 3, int nType = _BACKGROUND);
    KImageGray  Erosion(KImageGray& igGray, int mSize = 3, int nType = _BACKGROUND);
    KImageGray  Opening(KImageGray& igGray, int mSize = 3, int nType = _BACKGROUND);
    KImageGray  Closing(KImageGray& igGray, int mSize = 3, int nType = _BACKGROUND);

    _1DPIXEL    Labeling(KImageGray& igGray, int nType = _BACKGROUND);

    void        HistogramEqualization(KImageGray& igImg);
    void        HistogramEqualization(KImageColor& icImg);
    void        HistogramMatching(KImageGray& oriImg, KImageGray& dstImg);
    void        HistogramMatching(KImageColor& oriImg, KImageColor& dstImg);

    KImageGray  GaussianNoiseToGrayImage(KImageGray& igImg, double mean, double var);
    KImageColor GaussianNoiseToColorImage(KImageColor& icImg, double* mean, double* var);
    KImageGray  PepperSaltToGrayImage(KImageGray& igImg, double percent = 0.1);
    KImageColor PepperSaltToColorImage(KImageColor& icImg, double percent = 0.1);
    KImageGray  GaussianSmoothing(KImageGray& igImg, const double& sigma = 0.3);
    KImageColor GaussianSmoothing(KImageColor& icImg, const double& sigma = 0.3);
    KImageGray  MedianFiltering(KImageGray& igImg, const int kSize = 3);
    KImageColor MedianFiltering(KImageColor& icImg, const int kSize = 3);

    KImageGray  FDG(KImageGray& igImg, const double& sigma = 0.3);
    KImageGray  CannyEdge(KImageGray& igImg, double t0 = 10, double t1 = 30, const double &sigma=0.3);

    void        DrawHistgram(QVector<double>& x, QVector<double>& y, char* name = "Plot");

    _EDGEIMG    showGradient(){return edgeData;};
};


#endif // KIMGPROCESS_H
